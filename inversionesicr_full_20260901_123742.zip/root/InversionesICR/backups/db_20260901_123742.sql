--
-- PostgreSQL database dump
--

\restrict sKVslt88Kby2DMyECW5rtkWyRx9cidZVdOL01jnFCdTIj2jrK1f1J8eM64CEdRJ

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: HeroDisplayMode; Type: TYPE; Schema: public; Owner: icr
--

CREATE TYPE public."HeroDisplayMode" AS ENUM (
    'BANNERS_ONLY',
    'BANNERS_OVER_ANIMATION',
    'ANIMATION_ONLY'
);


ALTER TYPE public."HeroDisplayMode" OWNER TO icr;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: icr
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'EDITOR',
    'CLIENT'
);


ALTER TYPE public."Role" OWNER TO icr;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Banner; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."Banner" (
    id text NOT NULL,
    "titleEs" text NOT NULL,
    "titleEn" text,
    "descEs" text NOT NULL,
    "descEn" text,
    "imageKey" text NOT NULL,
    "ctaLabelEs" text,
    "ctaLabelEn" text,
    "ctaHref" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Banner" OWNER TO icr;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    slug text NOT NULL,
    "nameEs" text NOT NULL,
    "nameEn" text
);


ALTER TABLE public."Category" OWNER TO icr;

--
-- Name: ClientAccess; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."ClientAccess" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "projectId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ClientAccess" OWNER TO icr;

--
-- Name: ContactMessage; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."ContactMessage" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    subject text,
    body text NOT NULL,
    "ipHash" text,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ContactMessage" OWNER TO icr;

--
-- Name: Project; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    slug text NOT NULL,
    "titleEs" text NOT NULL,
    "titleEn" text,
    "descEs" text NOT NULL,
    "descEn" text,
    location text,
    "categoryId" text NOT NULL,
    "mainImageKey" text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Project" OWNER TO icr;

--
-- Name: ProjectImage; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."ProjectImage" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "imageKey" text NOT NULL,
    alt text,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."ProjectImage" OWNER TO icr;

--
-- Name: ProjectSlugAlias; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."ProjectSlugAlias" (
    id text NOT NULL,
    alias text NOT NULL,
    "projectId" text NOT NULL
);


ALTER TABLE public."ProjectSlugAlias" OWNER TO icr;

--
-- Name: Settings; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."Settings" (
    id integer DEFAULT 1 NOT NULL,
    "heroDisplayMode" public."HeroDisplayMode" DEFAULT 'BANNERS_OVER_ANIMATION'::public."HeroDisplayMode" NOT NULL,
    "maxActiveBanners" integer DEFAULT 5 NOT NULL,
    "animIntensity" double precision DEFAULT 1.6 NOT NULL,
    "defaultLocale" text DEFAULT 'es'::text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Settings" OWNER TO icr;

--
-- Name: SiteContact; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."SiteContact" (
    id integer DEFAULT 1 NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    whatsapp text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    "addressLine" text DEFAULT ''::text NOT NULL,
    "addressCity" text DEFAULT ''::text NOT NULL,
    cities text DEFAULT ''::text NOT NULL,
    "instagramUrl" text DEFAULT ''::text NOT NULL,
    "facebookUrl" text DEFAULT ''::text NOT NULL,
    "linkedinUrl" text DEFAULT ''::text NOT NULL,
    "tiktokUrl" text DEFAULT ''::text NOT NULL,
    "youtubeUrl" text DEFAULT ''::text NOT NULL,
    "twitterUrl" text DEFAULT ''::text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SiteContact" OWNER TO icr;

--
-- Name: User; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'EDITOR'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO icr;

--
-- Name: VictronConfig; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."VictronConfig" (
    id integer DEFAULT 1 NOT NULL,
    "encryptedToken" text DEFAULT ''::text NOT NULL,
    "tokenIv" text DEFAULT ''::text NOT NULL,
    "tokenTag" text DEFAULT ''::text NOT NULL,
    "victronUserId" integer,
    "victronUserName" text,
    "victronEmail" text,
    "lastTestedAt" timestamp(3) without time zone,
    "lastTestOk" boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VictronConfig" OWNER TO icr;

--
-- Name: VictronSite; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public."VictronSite" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "idSite" integer NOT NULL,
    "displayName" text,
    "isPublicMetrics" boolean DEFAULT false NOT NULL,
    "showPv" boolean DEFAULT true NOT NULL,
    "showBattery" boolean DEFAULT true NOT NULL,
    "showLoad" boolean DEFAULT true NOT NULL,
    "showGrid" boolean DEFAULT false NOT NULL,
    "lastSyncAt" timestamp(3) without time zone,
    "lastSnapshot" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VictronSite" OWNER TO icr;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: icr
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO icr;

--
-- Data for Name: Banner; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."Banner" (id, "titleEs", "titleEn", "descEs", "descEn", "imageKey", "ctaLabelEs", "ctaLabelEn", "ctaHref", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
cmouu9q18000001p3iqnnslvc	Banner	Banner	Test	Test	2026/05/58204da62dd4279d739976b1.jpg	\N	\N	\N	0	t	2026-05-07 02:00:13.581	2026-05-07 22:25:06.406
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."Category" (id, slug, "nameEs", "nameEn") FROM stdin;
cmpd6ss4f000901p306kj6vqt	industria-textil	Industria Textil 	Textile Industry
cmpcw4qc9000301p3hgzksuu8	Sector-comercial	Sector Comercial	Commercial Sector 
cmpcy0ros000601p3xxg5v0hj	Sector-minero	Sector Minero 	Mining Sector 
cmpcw8ke7000501p3blw3g5nd	Sector-industrial 	Sector Industrial 	Industrial Sector
cmpd6ye7m000a01p3fpu78ubu	soluciones-energeticas	Soluciones Energéticas	Soluciones Energéticas
cmpd7qsgw000c01p37ll8wwjv	sistemas-de-respaldo-energetico	Sistemas de respaldo Energético	Energy Backup Systems
\.


--
-- Data for Name: ClientAccess; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."ClientAccess" (id, "userId", "projectId", "createdAt") FROM stdin;
\.


--
-- Data for Name: ContactMessage; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."ContactMessage" (id, name, email, phone, subject, body, "ipHash", "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."Project" (id, slug, "titleEs", "titleEn", "descEs", "descEn", location, "categoryId", "mainImageKey", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
cmpcyf88z000701p3skf4oy1m	implementacion-de-sistema-fotovoltaico-industrial-quellaveco	Implementación de Sistema Fotovoltaico Industrial – Quellaveco	Industrial Photovoltaic System Implementation – Quellaveco	Quellaveco, una de las operaciones mineras más importantes del Perú y referente de la minería moderna en Sudamérica, requiere soluciones energéticas confiables y eficientes capaces de operar bajo condiciones de alta exigencia en entornos industriales de gran escala.\r\n\r\nEn este contexto, Inversiones ICR participó en la implementación de un sistema de respaldo energético orientado a optimizar la estabilidad operativa y fortalecer la transición hacia soluciones energéticas más sostenibles dentro del campamento minero. El proyecto integró infraestructura fotovoltaica, sistemas avanzados de almacenamiento energético y soluciones de integración eléctrica diseñadas para mejorar la eficiencia energética de las operaciones.\r\n\r\nLa implementación incluyó un banco de energía de alta capacidad, sistemas de conversión energética e infraestructura especializada para garantizar un suministro confiable y continuo en áreas estratégicas de la operación minera.\r\n\r\nGracias a esta solución, se logró reducir la dependencia de sistemas convencionales de generación eléctrica, optimizando el consumo energético y contribuyendo a la disminución de emisiones de CO₂ dentro de las operaciones del proyecto.\r\n\r\n	Quellaveco, one of Peru’s most important mining operations and a benchmark for modern mining in South America, requires reliable and efficient energy solutions capable of operating under highly demanding large-scale industrial conditions.\r\n\r\nIn this context, Inversiones ICR participated in the implementation of an energy backup system aimed at optimizing operational stability and strengthening the transition toward more sustainable energy solutions within the mining camp. The project integrated photovoltaic infrastructure, advanced energy storage systems, and electrical integration solutions designed to improve operational energy efficiency.\r\n\r\nThe implementation included a high-capacity energy storage bank, power conversion systems, and specialized infrastructure to ensure reliable and continuous power supply in strategic areas of the mining operation.\r\n\r\nThanks to this solution, dependency on conventional power generation systems was reduced, optimizing energy consumption and contributing to lower CO₂ emissions within the project’s operations.	MOQUEGUA-PERÚ	cmpcy0ros000601p3xxg5v0hj	2026/05/29a73bc2aa353d2087cacca2.jpg	0	t	2026-05-19 18:16:20.099	2026-06-02 17:29:10.07
cmpq09p1s000001pfro2bgfzp	sistema-de-energia-solar-para-la-optimizacion-industrial-de-kleinfor	Sistema de Energía Solar para la Optimización Industrial de Kleinfor 	Solar Energy System for Industrial Optimization at Kleinfor 	Inversiones ICR puso en operación un nuevo sistema de energía solar fotovoltaica para la empresa textil Kleinfor, ubicada en la ciudad de Arequipa, consolidando el uso de energías renovables dentro del sector industrial textil peruano.\r\n\r\nEl proyecto fue desarrollado con el objetivo de optimizar el consumo energético de la planta de producción, integrando una solución fotovoltaica diseñada para abastecer parte importante de la demanda eléctrica de las máquinas y equipos utilizados en los procesos de fabricación textil.\r\n\r\nLa implementación del sistema incluyó la instalación estratégica de 15 paneles solares fotovoltaicos, permitiendo aprovechar la alta radiación solar de Arequipa y mejorar la eficiencia operativa de la empresa desde el primer día de funcionamiento.\r\n\r\nGracias a esta solución energética, Kleinfor fortalece su compromiso con la sostenibilidad y la reducción de su huella de carbono, incorporando tecnologías limpias que contribuyen a una operación más eficiente, competitiva y alineada con los nuevos estándares ambientales de la industria.\r\n\r\nAdemás de los beneficios ambientales, el sistema permite reducir el consumo de energía convencional y generar ahorros energéticos sostenidos en el tiempo, aportando mayor estabilidad y eficiencia a las operaciones de la planta textil.\r\n\r\nCon este proyecto, Inversiones ICR reafirma su capacidad para desarrollar soluciones solares integrales para el sector industrial, combinando ingeniería especializada, ejecución técnica y acompañamiento profesional en cada etapa del proyecto, ayudando a las empresas a transformar la energía en una ventaja competitiva.	Inversiones ICR commissioned a new photovoltaic solar energy system for the textile company Kleinfor, located in the city of Arequipa, strengthening the integration of renewable energy solutions within Peru’s textile industrial sector.\r\n\r\nThe project was developed to optimize the plant’s energy consumption by implementing a photovoltaic solution designed to supply a significant portion of the electricity demand required by the machinery and equipment used in textile manufacturing processes.\r\n\r\nThe system included the strategic installation of 15 photovoltaic solar panels, taking advantage of Arequipa’s high solar radiation levels and improving the company’s operational efficiency from the very first day of operation.\r\n\r\nThrough this renewable energy solution, Kleinfor reinforces its commitment to sustainability and carbon footprint reduction by incorporating clean technologies that support a more efficient, competitive, and environmentally responsible operation.\r\n\r\nIn addition to its environmental benefits, the system helps reduce conventional electricity consumption and generate long-term energy savings, providing greater operational stability and efficiency for the textile plant.\r\n\r\nWith this project, Inversiones ICR reaffirms its ability to deliver comprehensive solar solutions for the industrial sector, combining specialized engineering, technical execution, and professional support throughout every stage of the project, helping companies transform energy into a strategic competitive advantage.	Arequipa-Perú	cmpd6ss4f000901p306kj6vqt	2026/05/832026dc369b01e7d415a2b2.jpg	0	t	2026-05-28 21:29:01.456	2026-05-28 21:29:03.807
cmpd88mtp000d01p3ifvg6gqz	sistema-de-respaldo-energetico-para-infraestructura-comercial-sauna-adan-y-eva	Sistema de Respaldo Energético para Infraestructura  – Sauna Adán y Eva	Energy Backup System for  Infrastructure – Sauna Adán y Eva	En un contexto donde la eficiencia energética y la continuidad operativa son fundamentales para el sector comercial y de servicios, Inversiones ICR desarrolló una solución de respaldo energético para las instalaciones de Sauna Adán y Eva, uno de los centros de bienestar y relajación más reconocidos de la ciudad de Tacna.\r\n\r\nEl proyecto fue diseñado para optimizar el consumo energético de sus instalaciones mediante la integración de sistemas fotovoltaicos, almacenamiento energético e infraestructura eléctrica especializada, permitiendo mejorar la estabilidad operativa de áreas de alta demanda energética como sistemas de climatización, bombeo, iluminación y equipamiento operativo.\r\n\r\nLa implementación incluyó soluciones avanzadas de conversión energética, monitoreo inteligente y sistemas híbridos de respaldo orientados a maximizar la eficiencia del sistema y reducir la dependencia de fuentes convencionales de generación eléctrica.\r\n\r\nComo parte del desarrollo del proyecto, se incorporaron sistemas de almacenamiento energético de alta eficiencia y monitoreo especializado para optimizar el rendimiento energético de la operación comercial y garantizar una mayor continuidad operativa.\r\n\r\nGracias a esta solución energética integral, la operación logró avanzar hacia un modelo más sostenible y eficiente, reduciendo su huella de carbono e integrando tecnologías orientadas a la gestión inteligente de energía.	In a context where energy efficiency and operational continuity are essential for the commercial and service sector, Inversiones ICR developed an energy backup solution for the facilities of Sauna Adán y Eva, one of the most recognized wellness and relaxation centers in the city of Tacna.\r\n\r\nThe project was designed to optimize the facility’s energy consumption through the integration of photovoltaic systems, energy storage, and specialized electrical infrastructure, improving operational stability in high-demand areas such as climate control systems, pumping equipment, lighting, and operational infrastructure.\r\n\r\nThe implementation included advanced power conversion solutions, intelligent monitoring systems, and hybrid backup technologies focused on maximizing system efficiency and reducing dependency on conventional power generation sources.\r\n\r\nAs part of the project development, high-efficiency energy storage systems and specialized monitoring solutions were integrated to optimize commercial operational performance and ensure greater operational continuity.\r\n\r\nThanks to this integrated energy solution, the operation advanced toward a more sustainable and efficient model by reducing its carbon footprint and integrating technologies focused on intelligent energy management.	Tacna-Perú	cmpd7qsgw000c01p37ll8wwjv	2026/05/ca16bb96b9126b0c7db5f6fd.png	0	t	2026-05-19 22:51:08.558	2026-06-02 22:31:29.967
cmpd657ne000801p37mgqh2gh	carport-solar-para-infraestructura-operativa-quellaveco	Carport Solar  – Quellaveco	Solar Carport  – Quellaveco	Inversiones ICR desarrolló la instalación de un sistema solar tipo carport orientado a optimizar el aprovechamiento energético dentro de las áreas operativas del campamento minero.\r\n\r\nLa implementación integró una estructura solar diseñada para generar energía renovable mientras proporciona cobertura y funcionalidad a los espacios vehiculares y operativos de la instalación. Esta solución permitió complementar la infraestructura energética del proyecto principal mediante generación fotovoltaica de alta eficiencia adaptada a entornos industriales de gran exigencia.\r\n\r\nEl sistema fue desarrollado bajo criterios de ingeniería especializada y sostenibilidad energética, contribuyendo a mejorar la eficiencia operativa y reforzar el compromiso de la operación minera con la transición hacia tecnologías energéticas más limpias y sostenibles.	Inversiones ICR developed the installation of a solar carport system aimed at optimizing energy utilization within the operational areas of the mining camp.\r\n\r\nThe implementation integrated a solar structure designed to generate renewable energy while providing coverage and functionality for vehicular and operational spaces within the facility. This solution complemented the main project’s energy infrastructure through high-efficiency photovoltaic generation adapted to highly demanding industrial environments.\r\n\r\nThe system was developed under specialized engineering and energy sustainability standards, contributing to improved operational efficiency and reinforcing the mining operation’s commitment to cleaner and more sustainable energy technologies.	Moquegua-Perú	cmpcy0ros000601p3xxg5v0hj	2026/05/2e1228318418584da0dcf66c.jpg	0	t	2026-05-19 21:52:29.69	2026-05-19 21:53:11.669
cmpwwk1bk000001nkk4puun52	sistema-de-almacenamiento-energetico-inteligente	Sistema de Almacenamiento Energético Inteligente	Intelligent Energy Storage System 	Como parte de la estrategia de optimización y modernización energética implementada en el Parque Chen Chen, Inversiones ICR desarrolló una solución avanzada de almacenamiento energético orientada a mejorar la estabilidad, eficiencia y continuidad del suministro eléctrico de la instalación.\r\nEl proyecto incorporó baterías de litio Dawnice de última generación, una tecnología reconocida por su alta densidad energética, prolongada vida útil y excelente desempeño en aplicaciones de almacenamiento de energía renovable. Estas características permiten maximizar el aprovechamiento de la energía disponible, almacenándola de forma segura para su utilización en horarios nocturnos, períodos de mayor demanda o ante eventuales interrupciones del suministro eléctrico.\r\nLa integración de sistemas de almacenamiento energético permite incrementar significativamente la autonomía operativa de la instalación, reducir la dependencia de fuentes convencionales de energía y optimizar el consumo energético de manera eficiente y sostenible.\r\nLa solución fue complementada con equipos de conversión y monitoreo inteligente que permiten supervisar el comportamiento del sistema en tiempo real, facilitando una gestión energética más eficiente y un mejor control sobre la generación, almacenamiento y consumo de energía.\r\nGracias a esta implementación, el Parque Chen Chen fortalece su infraestructura energética mediante una solución moderna, segura y confiable, preparada para responder a las necesidades energéticas actuales y futuras, promoviendo al mismo tiempo una operación más sostenible y respetuosa con el medio ambiente.	As part of the energy optimization and modernization strategy implemented at Chen Chen Park, Inversiones ICR developed an advanced energy storage solution designed to improve the stability, efficiency, and reliability of the facility's power supply.\r\nThe project incorporated state-of-the-art Dawnice lithium batteries, a technology recognized for its high energy density, extended service life, and outstanding performance in renewable energy storage applications. These features maximize the use of available energy by safely storing it for nighttime consumption, peak demand periods, or unexpected power interruptions.\r\nThe integration of energy storage systems significantly increases the facility’s operational autonomy, reduces dependence on conventional energy sources, and optimizes energy consumption in an efficient and sustainable manner.\r\nThe solution was complemented with advanced power conversion and intelligent monitoring systems that provide real-time supervision of the energy infrastructure, enabling more efficient energy management and improved control over energy generation, storage, and consumption.\r\nThrough this implementation, Chen Chen Park strengthens its energy infrastructure with a modern, reliable, and secure solution designed to meet current and future energy demands while promoting a more sustainable and environmentally responsible operation.	MOQUEGUA - PERÚ	cmpd7qsgw000c01p37ll8wwjv	2026/06/eb9e811b1ee89633963bf5e0.jpg	0	t	2026-06-02 17:19:28.688	2026-06-02 17:28:21.818
cmpwwos8j000101nkzfwkf1e7	sistema-hibrido-de-generacion-y-respaldo-energetico	Sistema Híbrido de Generación y Respaldo Energético 	Hybrid Energy Generation and Backup System	Ubicado en la ciudad de Arequipa, el Edificio Pozo Negro representa un ejemplo de cómo las tecnologías de generación y almacenamiento energético pueden integrarse para mejorar la eficiencia, confiabilidad y autonomía de las edificaciones modernas.\r\nCon el objetivo de optimizar el consumo energético y fortalecer la continuidad operativa de la infraestructura, Inversiones ICR desarrolló una solución híbrida que combina generación fotovoltaica, almacenamiento energético y gestión inteligente de la energía, permitiendo un mayor aprovechamiento de los recursos renovables disponibles.\r\nEl proyecto incorporó un sistema fotovoltaico compuesto por seis módulos solares de 620 W y tres módulos de 550 W, diseñados para aprovechar eficientemente la radiación solar y contribuir a la reducción del consumo eléctrico proveniente de la red convencional. La energía generada es administrada mediante un inversor Victron Energy de 48 V y 3000 VA, reconocido internacionalmente por su alto rendimiento, confiabilidad y capacidad de gestión energética avanzada.\r\nComo parte de la solución, se integró un banco de tres baterías de litio de alta eficiencia que permite almacenar la energía producida durante el día para su utilización en horarios nocturnos o durante eventuales interrupciones del suministro eléctrico, garantizando una mayor estabilidad y autonomía energética para la operación del edificio.\r\nLa combinación de generación solar, almacenamiento energético y tecnología de monitoreo inteligente permite optimizar el rendimiento del sistema, mejorar la eficiencia operativa y avanzar hacia un modelo energético más sostenible, reduciendo la dependencia de fuentes convencionales y fortaleciendo la seguridad energética de la instalación.	Located in the city of Arequipa, the Pozo Negro Building demonstrates how energy generation and storage technologies can be integrated to improve efficiency, reliability, and energy independence in modern infrastructure.\r\nTo optimize energy consumption and strengthen operational continuity, Inversiones ICR developed a hybrid solution that combines photovoltaic generation, energy storage, and intelligent energy management, enabling greater utilization of available renewable resources.\r\nThe project incorporated a photovoltaic system consisting of six 620 W solar modules and three 550 W solar modules, designed to efficiently capture solar energy and reduce dependence on conventional electricity sources. The generated energy is managed through a 48 V, 3000 VA Victron Energy inverter, internationally recognized for its performance, reliability, and advanced energy management capabilities.\r\nAs part of the solution, a high-efficiency lithium battery bank composed of three lithium batteries was integrated to store solar energy generated during the day for use during nighttime hours or power outages, ensuring greater operational stability and energy autonomy for the building.\r\nThe combination of solar generation, energy storage, and intelligent monitoring technology optimizes system performance, improves operational efficiency, and supports a more sustainable energy model by reducing dependence on conventional power sources while enhancing energy security.	AREQUIPA-PERÚ	cmpd6ye7m000a01p3fpu78ubu	2026/06/632afc78ccbe0c1a97e591ef.jpg	0	t	2026-06-02 17:23:10.195	2026-06-02 17:23:13.564
cmpq25v4w000101pfhmufbm41	sistema-solar-inteligente-con-almacenamiento-energetico-para-el-parque-chen-chen	Sistema Solar Inteligente con Almacenamiento Energético para el Parque Chen Chen	Smart Solar Energy System with Battery Storage for Chen Chen Park	Inversiones ICR desarrolló e implementó un moderno sistema de energía solar fotovoltaica con almacenamiento energético para el Parque Chen Chen, ubicado en la provincia de Mariscal Nieto, Moquegua, consolidando una solución energética sostenible orientada al funcionamiento continuo de la infraestructura pública del parque.\r\n\r\nEl proyecto fue diseñado para garantizar el abastecimiento energético del sistema de iluminación del parque durante el día y la noche, mediante la integración de una planta solar fotovoltaica compuesta por 42 paneles solares y un sistema BEST de almacenamiento energético de la marca Dawince, equipado con 7 baterías de litio de alto rendimiento.\r\n\r\nLa solución energética implementada permite suministrar energía de manera continua a los tableros de iluminación del parque, asegurando una operación estable y eficiente las 24 horas del día, los 7 días de la semana. Gracias a esta infraestructura, el sistema reduce significativamente la dependencia de la red eléctrica convencional de Electrosur S.A., fortaleciendo la autonomía energética del proyecto.\r\n\r\nEl parque cuenta con dos tableros fotovoltaicos independientes: uno destinado al sistema de bombeo y otro orientado exclusivamente al sistema de iluminación. La instalación ejecutada por Inversiones ICR fue diseñada específicamente para asumir el abastecimiento energético integral del sistema de iluminación del parque, garantizando continuidad operativa incluso durante horarios nocturnos y condiciones de alta demanda.\r\n\r\nLa implementación contempló ingeniería especializada, planificación técnica, instalación electromecánica, configuración del sistema BEST de almacenamiento y puesta en marcha integral del sistema fotovoltaico, todo ello ejecutado por personal técnico calificado e ingenieros especializados en soluciones energéticas renovables.\r\n\r\nAdemás de optimizar el consumo energético del parque, el proyecto contribuye directamente a la sostenibilidad urbana de la ciudad de Moquegua, incorporando energía limpia y tecnologías de almacenamiento de última generación que permiten maximizar la eficiencia energética y reducir el impacto ambiental de la infraestructura pública.	Inversiones ICR developed and implemented an advanced photovoltaic solar energy system with energy storage for Chen Chen Park, located in the province of Mariscal Nieto, Moquegua, delivering a sustainable energy solution designed for the continuous operation of the park’s public infrastructure.\r\n\r\nThe project was engineered to ensure uninterrupted power supply for the park’s lighting system during both daytime and nighttime operation through the integration of a photovoltaic solar plant composed of 42 solar panels and a BEST energy storage system from the Dawince brand, equipped with 7 high-performance lithium batteries.\r\n\r\nThe implemented energy solution provides continuous power to the park’s lighting distribution boards, ensuring stable and efficient operation 24 hours a day, 7 days a week. Thanks to this infrastructure, the system significantly reduces dependence on the conventional electrical grid operated by Electrosur S.A., strengthening the project’s energy autonomy.\r\n\r\nThe park includes two independent photovoltaic distribution boards: one dedicated to the pumping system and another exclusively designed for the lighting system. The installation executed by Inversiones ICR was specifically designed to fully supply the park’s lighting infrastructure, ensuring operational continuity even during nighttime operation and high-demand conditions.\r\n\r\nThe implementation included specialized engineering, technical planning, electromechanical installation, configuration of the BEST energy storage system, and full commissioning of the photovoltaic solution, all executed by qualified technical personnel and engineers specialized in renewable energy systems.\r\n\r\nIn addition to optimizing the park’s energy consumption, the project directly contributes to the urban sustainability goals of the city of Moquegua by integrating clean energy and next-generation storage technologies that maximize energy efficiency while reducing the environmental impact of public infrastructure.	 MOQUEGUA-PERÚ	cmpd6ye7m000a01p3fpu78ubu	2026/05/7d026aae2f614b03b6840008.jpg	0	t	2026-05-28 22:22:01.952	2026-06-02 17:27:23.205
cmpwy0wwh000201nkvzz5aued	sistema-hibrido-de-energia-solar-y-respaldo-energetico-radio-primavera	Sistema Híbrido de Energía Solar y Respaldo Energético – Radio Primavera	Hybrid Solar and Energy Backup System – Radio Primavera	La continuidad del suministro eléctrico es un factor fundamental para garantizar el funcionamiento ininterrumpido de los sistemas de comunicación y transmisión. Con el objetivo de fortalecer su autonomía energética y mejorar la confiabilidad de sus operaciones, Inversiones ICR desarrolló una solución híbrida de generación y almacenamiento energético para las instalaciones de Radio Primavera.\r\n\r\nEl proyecto incorporó un sistema fotovoltaico compuesto por ocho paneles solares de alta eficiencia, diseñados para aprovechar el recurso solar disponible y contribuir a la reducción del consumo energético proveniente de la red eléctrica convencional.\r\n\r\nLa energía generada es gestionada mediante un inversor Victron Energy de 3000 VA, una tecnología reconocida a nivel mundial por su alto rendimiento, confiabilidad y capacidad de administración inteligente de energía. Este equipo permite optimizar la conversión y distribución de la energía, garantizando una operación estable y eficiente del sistema.\r\n\r\nComo parte de la solución, se integraron dos baterías de litio Ritar de última generación, diseñadas para ofrecer una larga vida útil, alta profundidad de descarga y excelente estabilidad operativa. Gracias a su avanzada tecnología, estas baterías permiten almacenar la energía producida durante el día para su utilización en horarios nocturnos o durante interrupciones del suministro eléctrico, asegurando una mayor continuidad operativa y disponibilidad energética.\r\n\r\nLa combinación de generación solar, almacenamiento energético y gestión inteligente permite optimizar el rendimiento del sistema, reducir la dependencia de fuentes convencionales de energía y fortalecer la seguridad energética de la instalación.\r\n\r\nCon este proyecto, Radio Primavera avanza hacia un modelo energético más eficiente, sostenible y confiable, incorporando tecnologías de vanguardia que garantizan una operación continua y preparada para los desafíos energéticos del futuro.	Reliable power supply is essential to ensure uninterrupted communication and broadcasting operations. To strengthen energy independence and improve operational reliability, Inversiones ICR developed a hybrid energy generation and storage solution for the facilities of Radio Primavera.\r\n\r\nThe project incorporated a photovoltaic system consisting of eight high-efficiency solar panels designed to maximize the use of available solar resources and reduce dependence on conventional electricity sources.\r\n\r\nThe generated energy is managed through a 3000 VA Victron Energy inverter, a globally recognized technology known for its reliability, efficiency, and intelligent energy management capabilities. This equipment optimizes energy conversion and distribution, ensuring stable and efficient system performance.\r\n\r\nAs part of the solution, two state-of-the-art Ritar lithium batteries were integrated into the system. These batteries are designed to provide long service life, high depth of discharge, and excellent operational stability. Their advanced technology allows solar energy generated during the day to be stored and used during nighttime hours or power outages, ensuring greater operational continuity and energy availability.\r\n\r\nThe combination of solar generation, energy storage, and intelligent energy management optimizes system performance, reduces dependence on conventional energy sources, and strengthens the facility’s energy security.\r\n\r\nThrough this project, Radio Primavera moves toward a more efficient, sustainable, and reliable energy model by incorporating advanced technologies that support continuous operation and long-term energy resilience.	MOQUEGUA - PERÚ	cmpcw4qc9000301p3hgzksuu8	2026/06/5b00c491a326bb1bf0818629.jpg	0	t	2026-06-02 18:00:35.73	2026-06-02 18:00:35.73
cmpd7cv7g000b01p371zp86cs	sistema-fotovoltaico-para-infraestructura-electrica-seal-arequipa	Sistema Fotovoltaico Eléctrico – SEAL 	Electrical Photovoltaic System – SEAL 	Arequipa, una de las ciudades con mayor proyección energética del sur del Perú, continúa fortaleciendo su compromiso con el desarrollo sostenible y la incorporación de tecnologías orientadas a la generación de energía limpia y eficiente.\r\n\r\nEn el contexto de recuperación y reactivación operativa posterior a la pandemia del 2021, Inversiones ICR participó en la implementación de una solución fotovoltaica para la infraestructura energética de SEAL en la subestación de transformación del sector de Jesús, ubicada en Paucarpata, Arequipa.\r\n\r\nEl proyecto fue desarrollado con el objetivo de optimizar el abastecimiento energético de las instalaciones operativas y administrativas mediante generación fotovoltaica de alta eficiencia, permitiendo fortalecer la autosostenibilidad energética de la subestación y contribuir a la integración de energía renovable dentro del sistema eléctrico.\r\n\r\nLa implementación incluyó infraestructura fotovoltaica, sistemas de conversión energética e integración eléctrica especializada, permitiendo mejorar la eficiencia operativa y reducir la dependencia de fuentes convencionales de generación eléctrica.\r\n\r\nGracias a esta solución energética, la operación logró disminuir su huella de carbono y reforzar su compromiso con la transición hacia tecnologías sostenibles y energías renovables en la región sur del país.	Arequipa, one of the cities with the greatest energy development potential in southern Peru, continues strengthening its commitment to sustainable development and the integration of technologies focused on clean and efficient energy generation.\r\n\r\nDuring the post-pandemic recovery and operational reactivation period in 2021, Inversiones ICR participated in the implementation of a photovoltaic solution for the energy infrastructure of SEAL at the Jesús transformation substation located in Paucarpata, Arequipa.\r\n\r\nThe project was developed to optimize the energy supply of operational and administrative facilities through high-efficiency photovoltaic generation, strengthening the substation’s energy self-sufficiency and contributing to the integration of renewable energy into the electrical system.\r\n\r\nThe implementation included photovoltaic infrastructure, power conversion systems, and specialized electrical integration, improving operational efficiency and reducing dependency on conventional power generation sources.\r\n\r\nThanks to this energy solution, the operation reduced its carbon footprint and reinforced its commitment to the transition toward sustainable technologies and renewable energy in southern Peru.	 Arequipa-Perú	cmpcw8ke7000501p3blw3g5nd	2026/06/962253d15aa6f64828027f8d.jpg	0	t	2026-05-19 22:26:26.429	2026-06-02 20:50:27.495
\.


--
-- Data for Name: ProjectImage; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."ProjectImage" (id, "projectId", "imageKey", alt, "order") FROM stdin;
\.


--
-- Data for Name: ProjectSlugAlias; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."ProjectSlugAlias" (id, alias, "projectId") FROM stdin;
\.


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."Settings" (id, "heroDisplayMode", "maxActiveBanners", "animIntensity", "defaultLocale", "updatedAt") FROM stdin;
1	BANNERS_OVER_ANIMATION	5	5	es	2026-05-07 02:01:06.322
\.


--
-- Data for Name: SiteContact; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."SiteContact" (id, phone, whatsapp, email, "addressLine", "addressCity", cities, "instagramUrl", "facebookUrl", "linkedinUrl", "tiktokUrl", "youtubeUrl", "twitterUrl", "updatedAt") FROM stdin;
1	982 745 584	983 840 236	contacto@inversionesicr.com	Calle Pizarro  325 C-Arequipa	Arequipa- Moquegua	Todo el sur del Perú		https://www.facebook.com/profile.php?id=61579316365726&notif_id=1778191065832657&notif_t=profile_plus_admin_invite&ref=notif	https://www.linkedin.com/company/inversiones-icr/	https://www.tiktok.com/@inversionesicr?is_from_webapp=1&sender_device=pc	https://www.youtube.com/@INVERSIONESICR		2026-05-25 16:14:26.744
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."User" (id, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
cmoutyrv900000uql5ni82j0l	admin@inversionesicr.com	$2b$12$zQZLm37gAFJLsaxZ4M.w5uu.1HaSdIclFqMPcxe/Rx4rZ3mT2PHU6	ADMIN	2026-05-07 01:51:42.741	2026-05-07 01:51:42.741
\.


--
-- Data for Name: VictronConfig; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."VictronConfig" (id, "encryptedToken", "tokenIv", "tokenTag", "victronUserId", "victronUserName", "victronEmail", "lastTestedAt", "lastTestOk", "updatedAt") FROM stdin;
1				\N	\N	\N	\N	f	2026-05-28 16:13:02.397
\.


--
-- Data for Name: VictronSite; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public."VictronSite" (id, "projectId", "idSite", "displayName", "isPublicMetrics", "showPv", "showBattery", "showLoad", "showGrid", "lastSyncAt", "lastSnapshot", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: icr
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
44af6b9e-0d08-4818-b951-9aca6428e3b5	7e1bc007bbd837ce9dd8235a2901d04c17e2840018a8b29b358dc8ba0893493f	2026-05-07 01:51:03.801306+00	20260419193823_init	\N	\N	2026-05-07 01:51:03.627428+00	1
dad7980c-4c94-4faf-b75b-aa47030ebdae	429bd6d1c4973536622085b43b477ec06cd589cad566908bbcbca62849c40f8b	2026-05-21 20:37:10.344521+00	20260521181615_add_site_contact	\N	\N	2026-05-21 20:37:10.31391+00	1
7db65f0c-6091-4a94-a240-64e53444c7fc	31cdd2059998356dfa0516d8b428aced092ffde628ab78634dff4728478fe4e2	2026-05-21 20:37:10.415619+00	20260521183923_add_victron_integration	\N	\N	2026-05-21 20:37:10.345751+00	1
\.


--
-- Name: Banner Banner_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."Banner"
    ADD CONSTRAINT "Banner_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: ClientAccess ClientAccess_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ClientAccess"
    ADD CONSTRAINT "ClientAccess_pkey" PRIMARY KEY (id);


--
-- Name: ContactMessage ContactMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ContactMessage"
    ADD CONSTRAINT "ContactMessage_pkey" PRIMARY KEY (id);


--
-- Name: ProjectImage ProjectImage_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ProjectImage"
    ADD CONSTRAINT "ProjectImage_pkey" PRIMARY KEY (id);


--
-- Name: ProjectSlugAlias ProjectSlugAlias_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ProjectSlugAlias"
    ADD CONSTRAINT "ProjectSlugAlias_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: Settings Settings_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_pkey" PRIMARY KEY (id);


--
-- Name: SiteContact SiteContact_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."SiteContact"
    ADD CONSTRAINT "SiteContact_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VictronConfig VictronConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."VictronConfig"
    ADD CONSTRAINT "VictronConfig_pkey" PRIMARY KEY (id);


--
-- Name: VictronSite VictronSite_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."VictronSite"
    ADD CONSTRAINT "VictronSite_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Banner_isActive_order_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "Banner_isActive_order_idx" ON public."Banner" USING btree ("isActive", "order");


--
-- Name: Category_slug_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "Category_slug_idx" ON public."Category" USING btree (slug);


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: ClientAccess_projectId_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "ClientAccess_projectId_idx" ON public."ClientAccess" USING btree ("projectId");


--
-- Name: ClientAccess_userId_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "ClientAccess_userId_idx" ON public."ClientAccess" USING btree ("userId");


--
-- Name: ClientAccess_userId_projectId_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "ClientAccess_userId_projectId_key" ON public."ClientAccess" USING btree ("userId", "projectId");


--
-- Name: ContactMessage_createdAt_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "ContactMessage_createdAt_idx" ON public."ContactMessage" USING btree ("createdAt");


--
-- Name: ProjectImage_projectId_order_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "ProjectImage_projectId_order_idx" ON public."ProjectImage" USING btree ("projectId", "order");


--
-- Name: ProjectSlugAlias_alias_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "ProjectSlugAlias_alias_idx" ON public."ProjectSlugAlias" USING btree (alias);


--
-- Name: ProjectSlugAlias_alias_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "ProjectSlugAlias_alias_key" ON public."ProjectSlugAlias" USING btree (alias);


--
-- Name: Project_categoryId_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "Project_categoryId_idx" ON public."Project" USING btree ("categoryId");


--
-- Name: Project_isActive_order_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "Project_isActive_order_idx" ON public."Project" USING btree ("isActive", "order");


--
-- Name: Project_slug_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "Project_slug_key" ON public."Project" USING btree (slug);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: icr
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: VictronSite_idSite_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "VictronSite_idSite_key" ON public."VictronSite" USING btree ("idSite");


--
-- Name: VictronSite_projectId_key; Type: INDEX; Schema: public; Owner: icr
--

CREATE UNIQUE INDEX "VictronSite_projectId_key" ON public."VictronSite" USING btree ("projectId");


--
-- Name: ClientAccess ClientAccess_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ClientAccess"
    ADD CONSTRAINT "ClientAccess_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClientAccess ClientAccess_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ClientAccess"
    ADD CONSTRAINT "ClientAccess_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectImage ProjectImage_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ProjectImage"
    ADD CONSTRAINT "ProjectImage_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectSlugAlias ProjectSlugAlias_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."ProjectSlugAlias"
    ADD CONSTRAINT "ProjectSlugAlias_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: VictronSite VictronSite_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: icr
--

ALTER TABLE ONLY public."VictronSite"
    ADD CONSTRAINT "VictronSite_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict sKVslt88Kby2DMyECW5rtkWyRx9cidZVdOL01jnFCdTIj2jrK1f1J8eM64CEdRJ

